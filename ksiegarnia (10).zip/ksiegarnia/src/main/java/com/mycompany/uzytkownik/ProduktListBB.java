package com.mycompany.uzytkownik;

import java.util.List;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.inject.Inject;
import jakarta.ejb.EJB;
import jakarta.faces.context.Flash;

import com.mycompany.dao.ProduktDAO;
import com.mycompany.entities.Produkt;

@Named
@RequestScoped
public class ProduktListBB {
    private static final String PAGE_PRODUKT_DETAILS = "produktDetails?faces-redirect=true";
    private static final String PAGE_STAY_AT_THE_SAME = null;

    @EJB
    private ProduktDAO produktDAO;

    @Inject
    private Flash flash;

    public List<Produkt> getList() {
        return produktDAO.getFullList(); // Pobiera pełną listę produktów z bazy danych
    }

   public String viewProduktDetails(Produkt produkt) {
        // Przekierowanie na stronę szczegółów produktu z przekazaniem ID przez parametr URL
        return PAGE_PRODUKT_DETAILS + produkt.getIdProduktu();
    }
}
