package com.mycompany.uzytkownik;

import java.io.Serializable;

import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.context.Flash;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.IOException;
import jakarta.servlet.http.HttpSession;

import com.mycompany.dao.UzytkownikDAO;
import com.mycompany.entities.Uzytkownik;

@Named
@ViewScoped
public class UzytkownikRejestracjaBB implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final String PAGE_UZYTKOWNIK_LIST = "uzytkownikList?faces-redirect=true";
    private static final String PAGE_STAY_AT_THE_SAME = null;

    private Uzytkownik uzytkownik = new Uzytkownik();
    private String hasloConfirm;

    @EJB
    UzytkownikDAO uzytkownikDAO;

    @Inject
    FacesContext context;

    @Inject
    Flash flash;

    public Uzytkownik getUzytkownik() {
        return uzytkownik;
    }

    public String getHasloConfirm() {
        return hasloConfirm;
    }

    public void setHasloConfirm(String hasloConfirm) {
        this.hasloConfirm = hasloConfirm;
    }

    // Metoda uruchamiana przy załadowaniu strony
    public void onLoad() {
        // Jeśli potrzebujemy wczytać jakiekolwiek dane lub wykonać inne operacje przy ładowaniu strony, możemy dodać logikę tutaj.
    }

public String saveData() {
    // Sprawdzamy, czy hasło i potwierdzenie hasła są zgodne
    if (!uzytkownik.getHaslo().equals(hasloConfirm)) {
        // Jeżeli hasło i potwierdzenie hasła się nie zgadzają, pokazujemy komunikat o błędzie
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Hasła się nie zgadzają", null));
        return PAGE_STAY_AT_THE_SAME;
    }

    try {
        // Sprawdzamy, czy użytkownik już istnieje w bazie
        if (uzytkownikDAO.findByEmail(uzytkownik.getEmail()) != null) {
            // Jeżeli użytkownik o tym emailu już istnieje, pokazujemy komunikat o błędzie
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Użytkownik z takim adresem email już istnieje", null));
            return PAGE_STAY_AT_THE_SAME;
        }

        // Zapisujemy nowego użytkownika
        uzytkownikDAO.create(uzytkownik);

        // Po zapisaniu użytkownika, dodajemy informację do Flash
        flash.put("rejestracjaSukces", "Użytkownik został zarejestrowany pomyślnie!");

        return PAGE_UZYTKOWNIK_LIST;
    } catch (Exception e) {
        e.printStackTrace();
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Wystąpił błąd podczas rejestracji: " + e.getMessage(), null));
        return PAGE_STAY_AT_THE_SAME;
    }
}

}
