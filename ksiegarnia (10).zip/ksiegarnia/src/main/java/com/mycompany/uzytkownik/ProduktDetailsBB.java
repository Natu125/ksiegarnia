package com.mycompany.uzytkownik;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.ejb.EJB;
import jakarta.faces.context.FacesContext;

import com.mycompany.dao.ProduktDAO;
import com.mycompany.entities.Produkt;

@Named
@RequestScoped
public class ProduktDetailsBB {
    @EJB
    private ProduktDAO produktDAO;

    private Produkt produkt;

    public Produkt getProdukt() {
        if (produkt == null) {
            // Pobranie ID z parametru URL
            String idParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
            if (idParam != null) {
                try {
                    int id = Integer.parseInt(idParam);
                    produkt = produktDAO.findById(id); // Załaduj produkt z bazy danych
                } catch (NumberFormatException e) {
                    // Obsługa nieprawidłowego ID
                    produkt = null;
                }
            }
        }
        return produkt;
    }
}
