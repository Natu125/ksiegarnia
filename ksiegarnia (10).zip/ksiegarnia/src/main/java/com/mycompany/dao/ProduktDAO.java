package com.mycompany.dao;

import com.mycompany.entities.Produkt;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;
import java.util.Map;

@Stateless
public class ProduktDAO {

    @PersistenceContext
    private EntityManager em;
    
    

    /**
     * Pobiera pełną listę produktów z bazy danych.
     * 
     * @return Lista produktów
     */
    public List<Produkt> getFullList() {
        return em.createNamedQuery("Produkt.findAll", Produkt.class).getResultList();
    }

    /**
     * Pobiera listę produktów na podstawie kryteriów wyszukiwania.
     * 
     * @param searchParams Mapa z parametrami wyszukiwania
     * @return Lista produktów pasujących do kryteriów
     */
    public List<Produkt> getList(Map<String, Object> searchParams) {
        StringBuilder jpql = new StringBuilder("SELECT p FROM Produkt p WHERE 1=1");

        if (searchParams != null) {
            if (searchParams.containsKey("nazwa")) {
                jpql.append(" AND p.nazwa LIKE :nazwa");
            }
            if (searchParams.containsKey("cenaMin")) {
                jpql.append(" AND p.cena >= :cenaMin");
            }
            if (searchParams.containsKey("cenaMax")) {
                jpql.append(" AND p.cena <= :cenaMax");
            }
        }

        var query = em.createQuery(jpql.toString(), Produkt.class);

        if (searchParams != null) {
            if (searchParams.containsKey("nazwa")) {
                query.setParameter("nazwa", "%" + searchParams.get("nazwa") + "%");
            }
            if (searchParams.containsKey("cenaMin")) {
                query.setParameter("cenaMin", searchParams.get("cenaMin"));
            }
            if (searchParams.containsKey("cenaMax")) {
                query.setParameter("cenaMax", searchParams.get("cenaMax"));
            }
        }

        return query.getResultList();
    }

    /**
     * Zapisuje nowy produkt w bazie danych.
     * 
     * @param produkt Obiekt produktu do zapisania
     */
    public void create(Produkt produkt) {
        em.persist(produkt);
    }

    /**
     * Aktualizuje istniejący produkt w bazie danych.
     * 
     * @param produkt Obiekt produktu do aktualizacji
     */
    public void update(Produkt produkt) {
        em.merge(produkt);
    }

    /**
     * Usuwa produkt z bazy danych.
     * 
     * @param produkt Obiekt produktu do usunięcia
     */
    public void remove(Produkt produkt) {
        produkt = em.merge(produkt); // Upewniamy się, że obiekt jest zarządzany
        em.remove(produkt);
    }

    /**
     * Pobiera produkt na podstawie identyfikatora.
     * 
     * @param id Identyfikator produktu
     * @return Produkt, jeśli istnieje, lub null
     */
    public Produkt findById(int id) {
        return em.find(Produkt.class, id);
    }
}
